(function () {
  'use strict';
  const { data, store } = window.StarPath;
  const main = document.getElementById('main');
  const modal = document.getElementById('modal');
  const modalContent = document.getElementById('modal-content');
  const fileInput = document.getElementById('backup-file');
  const filters = { query: '', field: 'all', direction: 'all', favorites: false };
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let current = { page: 'home' };
  let renderedRoute = null;
  let pageSnapshot = null;
  let pageSnapshotTimer;
  let modalReturnFocus = null;
  let toastTimer;
  let pendingImport = null;
  const icons = {
    arrow: '<path d="M5 12h14m-6-6 6 6-6 6"/>',
    upRight: '<path d="M6 18 18 6M6 6h12v12"/>',
    star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9Z"/>',
    search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/>',
    trophy: '<path d="M8 3h8v6a4 4 0 0 1-8 0V3Zm4 10v6m-4 2h8M8 5H4v3a4 4 0 0 0 4 4m8-7h4v3a4 4 0 0 1-4 4"/>',
    book: '<path d="M12 6c-3-2-6-2-9-1v14c3-1 6-1 9 1 3-2 6-2 9-1V5c-3-1-6-1-9 1v14"/>',
    briefcase: '<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V3h8v4M3 12l9 3 9-3m-9 1v4"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    close: '<path d="m6 6 12 12M6 18 18 6"/>',
    chevron: '<path d="m9 5 7 7-7 7"/>',
    back: '<path d="m12 5-7 7 7 7M5 12h14"/>',
    download: '<path d="M12 3v12m-5-5 5 5 5-5M4 15v5h16v-5"/>',
    upload: '<path d="M12 16V4m-5 5 5-5 5 5M4 15v5h16v-5"/>',
    edit: '<path d="m14 5 5 5M4 20l5-1L20 8a3.5 3.5 0 0 0-5-5L4 14v6Z"/>',
    trash: '<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 11h18"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="m16 8-2 6-6 2 2-6 6-2Z"/>',
    shield: '<path d="M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6l-8-3Z"/><path d="m8 12 3 3 5-6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v1"/>',
    spark: '<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z"/>'
  };
  const icon = (name, extra = '') => '<svg class="icon ' + extra + '" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (icons[name] || icons.spark) + '</svg>';
  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const personById = id => data.alumni.find(item => item.id === id);
  const routeById = id => data.routes.find(item => item.id === id);
  const tags = values => values.map(value => '<span class="tag">' + esc(value) + '</span>').join('');
  const eyebrow = text => '<div class="eyebrow"><span></span>' + text + '</div>';
  const sectionHead = (kicker, title, subtitle, link = '') => '<div class="section-heading"><div><div class="section-kicker">' + kicker + '</div><h2>' + title + '</h2>' + (subtitle ? '<p>' + subtitle + '</p>' : '') + '</div>' + link + '</div>';
  function toast(message) {
    const target = document.getElementById('toast');
    target.textContent = message;
    target.classList.add('visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => target.classList.remove('visible'), 4200);
  }
  function saved(persisted, message) { toast(persisted ? message : message + '（仅本次打开有效，请导出备份）'); }
  function notice() {
    const target = document.getElementById('storage-notice');
    const status = store.status();
    target.hidden = status === 'persistent';
    if (status === 'damaged') target.innerHTML = '<span>' + icon('info') + '本机旧记录暂时无法读取，原始内容已保留。当前修改仅在本次打开有效，请及时导出备份。</span><button class="text-button" data-action="export-raw">下载原始记录</button>';
    else if (status === 'session') target.textContent = '当前浏览器无法保存本机记录。离开页面前，请到“我的成长”导出备份；关闭后本次进度可能丢失。';
  }
  function favoriteButton(person) {
    const active = store.get().favorites.includes(person.id);
    return '<button class="icon-button favorite-button ' + (active ? 'is-favorite' : '') + '" data-action="favorite" data-person="' + person.id + '" aria-pressed="' + active + '" aria-label="' + (active ? '取消收藏' : '收藏') + person.name + '" title="' + (active ? '取消收藏' : '收藏校友') + '">' + icon('star') + '</button>';
  }
  function portrait(person, big = false) {
    if (person.photo) {
      const photo = person.photo;
      return '<div class="portrait portrait-photo photo-' + esc(photo.style) + (big ? ' portrait-large' : '') + '"><img src="' + esc(photo.src) + '" alt="' + esc(photo.alt) + '" style="object-position:' + esc(photo.position) + '" decoding="async"' + (big ? '' : ' loading="lazy"') + '><span class="photo-caption" aria-hidden="true">' + (photo.style === 'event' ? '讲座现场' : photo.style === 'work' ? '工作中的校友' : '校友肖像') + '<span>人物档案 / ' + person.number + '</span></span></div>';
    }
    return '<div class="portrait portrait-' + person.color + (big ? ' portrait-large' : '') + '" aria-hidden="true"><span class="portrait-top">' + (person.photoNote ? esc(person.photoNote) : 'SHANGZHI ALUMNI') + '</span><span class="portrait-number">' + person.number + '</span><div class="portrait-orbit orbit-one"></div><div class="portrait-orbit orbit-two"></div><span class="portrait-initial">' + person.initial + '</span><span class="portrait-spark">✦</span><span class="portrait-bottom">' + esc(person.field) + '<span>人物档案 / ' + person.number + '</span></span></div>';
  }
  function personThumbnail(person) {
    return '<span class="person-initial-small portrait-' + person.color + '" aria-hidden="true">' + (person.photo ? '<img src="' + esc(person.photo.src) + '" alt="" style="object-position:' + esc(person.photo.position) + '" loading="lazy">' : person.initial) + '</span>';
  }
  function photoCredit(person) {
    if (!person.photo) return '<p class="photo-credit">' + esc(person.photoNote || '姓名图形卡片') + '</p>';
    return '<p class="photo-credit">图片来源：<a href="' + esc(person.photo.source.url) + '" target="_blank" rel="noopener noreferrer">' + esc(person.photo.credit) + icon('upRight') + '</a><span>' + esc(person.photo.source.date) + ' · 原图呈现</span></p>';
  }
  function personCard(person) {
    return '<article class="person-card"><div class="person-cover"><a href="#/alumni/' + person.id + '" tabindex="-1" aria-hidden="true">' + portrait(person) + '</a>' + favoriteButton(person) + '</div><div class="person-content"><div class="person-name-row"><h3><a href="#/alumni/' + person.id + '">' + person.name + '</a></h3><span class="cohort">' + person.cohort + '</span></div><p class="person-role">' + person.role + '</p><div class="tags">' + tags(person.tags) + '</div><a class="card-link" href="#/alumni/' + person.id + '">阅读成长故事' + icon('upRight') + '</a></div></article>';
  }
  function routeCard(route, number) {
    return '<article class="route-card route-' + route.color + '"><div class="route-card-top"><span class="route-icon">' + icon(route.icon) + '</span><span class="route-index">PATH / 0' + (number + 1) + '</span></div><h3><a href="#/paths/' + route.id + '">' + route.name + '</a></h3><p>' + route.subtitle + '</p><div class="route-meta"><span>' + route.stages.length + ' 个阶段 · ' + taskCount(route) + ' 项任务</span><span>·</span><span>' + route.duration + '</span></div><a href="#/paths/' + route.id + '" class="card-link">探索这条路线' + icon('arrow') + '</a></article>';
  }
  function historyEntries() {
    return data.anniversary.history.map(event => '<li class="history-entry"><span class="history-year">' + esc(event.year) + '</span><div><h3>' + esc(event.title) + '</h3><p>' + esc(event.text) + '</p>' + sourceLink(data.anniversary.source) + '</div></li>').join('');
  }
  function tributeSection() {
    return '<section class="section tribute-section" aria-labelledby="tribute-title"><div class="section-heading"><div><div class="eyebrow"><span></span>以成长，致母校</div><h2 id="tribute-title">把一份心意，变成三个行动。</h2><p>从了解母校，到认识榜样，再到完成自己的作品。</p></div></div><ol class="tribute-grid">' + data.anniversary.tribute.tasks.map((task, index) => '<li class="tribute-card"><div class="tribute-card-top">' + icon(task.icon) + '<span>0' + (index + 1) + '</span></div><h3>' + esc(task.stage) + '</h3><p>' + esc(task.description) + '</p><a class="card-link" href="' + esc(task.href) + '">' + esc(task.link) + icon('arrow') + '</a></li>').join('') + '</ol><div class="tribute-bottom"><div><strong>你的下一步，也是商职的新一页。</strong><p>行动为平台建议，完成情况由你自行记录；计划保存在本机。</p></div><button class="button primary" data-action="create-tribute">开启献礼计划' + icon('arrow') + '</button></div></section>';
  }
  function home() {
    const anniversary = data.anniversary;
    return '<div class="container home-page anniversary-home"><section class="anniversary-hero"><div class="anniversary-copy">' + eyebrow('商职星途 · 九秩校庆专题') + '<div class="anniversary-years">' + esc(anniversary.years) + '<span>薪火相传 · 共赴新程</span></div><h1>' + esc(anniversary.title) + '<br><span>' + esc(anniversary.subtitle) + '</span></h1><p class="anniversary-description">' + esc(anniversary.description) + '</p><div class="hero-actions"><a class="button primary" href="#/history">回望校史' + icon('arrow') + '</a><button class="button secondary" data-action="create-tribute">开启献礼计划' + icon('spark') + '</button></div><p class="anniversary-signature"><span></span>回望来路，让每一份成长续写荣光。</p></div><figure class="anniversary-visual"><img src="assets/anniversary-90.svg" width="650" height="580" alt="金色数字90、年轮与向上生长的线条，纪念1936至2026九秩商职"><figcaption>九十载弦歌不辍，一代代向新而行。</figcaption></figure></section><div class="anniversary-index"><span>九秩回响 <small>A SHARED JOURNEY</small></span><a href="#/history">01 回望校史' + icon('upRight') + '</a><a href="#/alumni">02 走近校友' + icon('upRight') + '</a><a href="#/paths">03 传承成长' + icon('upRight') + '</a></div>' +
      '<section class="section history-preview">' + sectionHead('THE YEARS THAT SHAPED US', '循着年轮，读懂来路', '从办学溯源到高职发展，回望有据可寻的历史坐标。', '<a class="text-link" href="#/history">走进九秩校史' + icon('arrow') + '</a>') + '<ol class="history-grid">' + historyEntries() + '</ol></section>' +
      '<section class="section">' + sectionHead('OUR PEOPLE, OUR STORIES', '岁月有光，校友有故事', '走近真实的商职校友，在他们的足迹里看见成长的力量。', '<a class="text-link" href="#/alumni">探索全部校友' + icon('arrow') + '</a>') + '<div class="people-grid">' + data.alumni.map(personCard).join('') + '</div></section>' +
      '<section class="section routes-section">' + sectionHead('CARRY THE SPIRIT FORWARD', '薪火相传，从你的下一步开始', '把榜样带来的启发，变成可以行动的成长路线。', '<a class="text-link" href="#/paths">进入成长传承' + icon('arrow') + '</a>') + '<div class="route-grid">' + data.routes.map(routeCard).join('') + '</div><p class="template-note">' + icon('info') + '路线为平台学习建议，可按自己的节奏调整，不代表校友本人经历或承诺。</p></section>' + tributeSection() + '</div>';
  }
  function historyPage() {
    const anniversary = data.anniversary;
    return '<div class="container inner-page history-page"><div class="page-heading">' + eyebrow('九秩校史 · 回望来路') + '<h1>九秩薪火，照亮新的出发。</h1><p>沿着公开资料留下的坐标，认识母校的来路，也找到与自己有关的那一页。</p></div><div class="history-heading-art"><span>' + esc(anniversary.years) + '</span><p>历史有出处，成长有回响。</p></div><section class="section"><h2 class="history-section-title">有据可寻的历史坐标</h2><ol class="history-timeline">' + historyEntries() + '</ol><p class="history-source-note">资料日期按官网文件目录标注为2024年，未推断具体发布日期。这里展示办学沿革的两个节点，并非完整校史。</p></section><section class="commemoration"><div class="commemoration-year">' + esc(anniversary.theme.year) + '</div><div><span class="section-kicker">' + esc(anniversary.theme.note) + '</span><h2>' + esc(anniversary.theme.title) + '</h2><p>' + esc(anniversary.theme.text) + '</p></div></section><section class="history-next"><div><span class="section-kicker">从母校的来路，走向自己的星途</span><h2>故事仍在继续，下一页有你。</h2><p>读一段校友经历，完成一份实践作品，让心意落在今天的行动里。</p></div><div class="hero-actions"><a class="button secondary" href="#/alumni">走近校友故事' + icon('arrow') + '</a><button class="button primary" data-action="create-tribute">开启献礼计划' + icon('spark') + '</button></div><p class="template-note">献礼行动为平台建议，完成情况由用户自行记录。</p></section></div>';
  }
  function alumniPage() {
    const fields = [...new Set(data.alumni.map(person => person.field))];
    return '<div class="container inner-page"><div class="page-heading">' + eyebrow('ALUMNI STORIES / 校友风采') + '<h1>商职走出的身影，照亮新的星途。</h1><p>在九秩校庆的相聚中，读一段真实经历，收藏一份成长启发。</p></div><section class="filter-panel" aria-label="校友搜索与筛选"><div class="search-row"><label class="search-input">' + icon('search') + '<input id="alumni-query" type="search" placeholder="搜索姓名、专业或成长关键词" value="' + esc(filters.query) + '" aria-label="搜索校友" maxlength="100"></label><button class="button ' + (filters.favorites ? 'primary' : 'secondary') + '" data-action="filter-favorites" aria-pressed="' + filters.favorites + '">' + icon('star') + '我的收藏</button></div><div class="filter-row"><label for="field-filter">专业领域</label><select id="field-filter"><option value="all">全部领域</option>' + fields.map(field => '<option value="' + esc(field) + '" ' + (filters.field === field ? 'selected' : '') + '>' + esc(field) + '</option>').join('') + '</select><span class="filter-label">成长方向</span><div class="filter-chips" role="group" aria-label="成长方向">' + ['all', '技能竞赛', '升学深造', '技术就业'].map(direction => '<button class="chip ' + (filters.direction === direction ? 'active' : '') + '" data-action="filter-direction" data-value="' + direction + '" aria-pressed="' + (filters.direction === direction) + '">' + (direction === 'all' ? '全部' : direction) + '</button>').join('') + '</div></div></section><div class="results-heading"><p id="results-count" role="status" aria-live="polite"></p><button class="text-button" data-action="reset-filters">重置筛选</button></div><div id="alumni-results" class="people-grid"></div><div class="source-note">' + icon('shield') + '<div><strong>真实故事，有据可寻</strong><p>收录内容来自学校官方报道，任职信息以报道时间为准。已核实的校友照片保留官方来源，详情页可查看原始报道；尚未取得本人照片时使用姓名图形。</p></div></div></div>';
  }
  function updateAlumniResults() {
    const target = document.getElementById('alumni-results');
    if (!target) return;
    const favorites = store.get().favorites;
    const query = filters.query.trim().toLowerCase();
    const results = data.alumni.filter(person => (filters.field === 'all' || person.field === filters.field) && (filters.direction === 'all' || person.tags.includes(filters.direction)) && (!filters.favorites || favorites.includes(person.id)) && [person.name, person.field, person.role, person.cohort, person.biography, ...person.tags].join(' ').toLowerCase().includes(query));
    target.innerHTML = results.length ? results.map(personCard).join('') : '<div class="empty-state full-width"><span class="empty-icon">' + icon(filters.favorites ? 'star' : 'search') + '</span><h2>' + (filters.favorites ? '这里还没有匹配的收藏' : '暂时没有找到匹配的校友') + '</h2><p>试试其他关键词，或清除筛选看看全部故事。</p><button class="button secondary" data-action="reset-filters">查看全部校友</button></div>';
    document.getElementById('results-count').innerHTML = '找到 <strong>' + results.length + '</strong> 位校友 <span> / 共 ' + data.alumni.length + ' 位已收录</span>';
  }
  const taskCount = route => route.stages.reduce((total, stage) => total + stage.tasks.length, 0);
  const projectById = id => data.practiceProjects.find(project => project.id === id);
  const textList = (items, ordered = false) => '<' + (ordered ? 'ol' : 'ul') + ' class="reading-list">' + items.map(item => '<li>' + esc(item) + '</li>').join('') + '</' + (ordered ? 'ol' : 'ul') + '>';
  const exampleBlock = (text, label = '填写示例') => '<div class="example-block"><span class="section-kicker">' + esc(label) + '</span><pre>' + esc(text) + '</pre></div>';
  function resourceCards(ids) {
    return '<div class="resource-grid">' + ids.map(id => {
      const resource = data.resources.find(item => item.id === id);
      return '<article class="resource-card"><a href="' + esc(resource.url) + '" target="_blank" rel="noopener noreferrer">' + esc(resource.title) + icon('upRight') + '</a><p><strong>读这里：</strong>' + esc(resource.section) + '</p><p>' + esc(resource.use) + '</p></article>';
    }).join('') + '</div>';
  }
  function methodSection(ids, title = '遇到困难，先看这些方法') {
    return '<section class="section learning-methods" id="methods">' + sectionHead('LEARN HOW TO LEARN', title, '按需展开：操作步骤、填写示例与检查清单。示例可以按自己的情况修改。') + '<div class="method-grid">' + [...new Set(ids)].map(id => {
      const method = data.methodCards.find(item => item.id === id);
      return '<details class="reading-details method-card" id="method-' + method.id + '"><summary><span><strong>' + esc(method.title) + '</strong><small>' + esc(method.subtitle) + '</small></span></summary><div class="reading-body">' + textList(method.steps, true) + exampleBlock(method.example) + '<h4>检查清单</h4>' + textList(method.checklist) + '</div></details>';
    }).join('') + '</div></section>';
  }
  function methodLinks(ids) {
    return '<div class="reading-links">' + ids.map(id => {
      const method = data.methodCards.find(item => item.id === id);
      return '<button class="text-link" data-action="scroll-to" data-value="method-' + id + '">' + esc(method.title) + icon('arrow') + '</button>';
    }).join('') + '</div>';
  }
  function practiceCard(project) {
    return '<article class="practice-card route-' + project.color + '"><div class="practice-card-top"><span class="section-kicker">' + esc(project.category) + '</span>' + icon(project.icon) + '</div><h3><a href="#/practice/' + project.id + '">' + esc(project.name) + '</a></h3><p>' + esc(project.summary) + '</p><div class="practice-output"><span>你会留下</span><strong>' + esc(project.outcome) + '</strong></div><a class="card-link" href="#/practice/' + project.id + '">跟着完成这个案例' + icon('arrow') + '</a></article>';
  }
  function practiceSection(ids = data.practiceProjects.map(project => project.id), title = '从第一份小作品开始') {
    return '<section class="section practice-section" id="practice-library">' + sectionHead('LEARNING BY MAKING', title, '原创教学案例 · 有起始材料、参考成品和明确的完成标准') + '<div class="practice-grid">' + ids.map(id => practiceCard(projectById(id))).join('') + '</div></section>';
  }
  function beginnerSection() {
    return '<section class="beginner-section"><div><span class="section-kicker">START SMALL / 零基础从这里开始</span><h2>第一份作品，<br>从改一行文字开始。</h2><p>不必先弄懂所有术语。打开示例、修改标题、看见变化，再一步步完成自己的校园指南。</p><a class="button primary" href="#/practice/campus-guide">开始网页入门练习' + icon('arrow') + '</a></div><ol class="beginner-steps"><li><span>01</span><div><strong>认识问题</strong><p>为 8 条模拟问答整理分类。</p></div></li><li><span>02</span><div><strong>动手做出结果</strong><p>加入搜索，检查手机阅读效果。</p></div></li><li><span>03</span><div><strong>把过程讲清楚</strong><p>记录测试，完成两分钟演示。</p></div></li></ol></section>';
  }
  function sourceLink(source) {
    return '<a class="inline-source" href="' + esc(source.url) + '" target="_blank" rel="noopener noreferrer">' + esc(source.title) + ' · ' + esc(source.date) + icon('upRight') + '</a>';
  }
  function personPage(person) {
    const learning = person.learning;
    const project = projectById(learning.projectId);
    return '<div class="container inner-page"><a class="back-link" href="#/alumni">' + icon('back') + '返回校友探索</a><section class="profile-hero"><div class="profile-portrait">' + portrait(person, true) + photoCredit(person) + '</div><div class="profile-intro">' + eyebrow('ALUMNI STORY / ' + person.number) + '<div class="profile-title"><h1>' + esc(person.name) + '</h1>' + favoriteButton(person) + '</div><div class="profile-meta">' + esc(person.cohort) + '<span>·</span>' + esc(person.major) + '</div><h2>' + esc(person.role) + '</h2><p>' + esc(person.summary) + '</p><div class="tags">' + tags(person.tags) + '</div></div></section>' +
      '<div class="profile-columns"><article><section class="story-intro"><div class="section-kicker">DOCUMENTED EXPERIENCE / 公开经历</div><h2>从公开记录认识这段经历</h2><p>' + esc(person.biography) + '</p><div class="reading-links">' + person.sources.map(sourceLink).join('') + '</div></section><section class="timeline-section"><h2>成长的关键坐标</h2><ol class="timeline">' + person.timeline.map((event, index) => '<li><span class="timeline-marker">' + (index === person.timeline.length - 1 ? '✦' : '') + '</span><span class="timeline-time">' + esc(event.time) + '</span><div><h3>' + esc(event.title) + '</h3><p>' + esc(event.text) + '</p>' + sourceLink(event.source) + '</div></li>').join('') + '</ol></section><section class="editor-analysis"><span class="section-kicker">EDITOR’S NOTES / 平台编辑分析</span><h2>' + esc(learning.label) + '</h2><p>' + esc(learning.analysis) + '</p><h3>理解这份资料的边界</h3><p>' + esc(learning.limits) + '</p><p class="editor-note">以下练习由平台设计，不是校友原话或本人建议。</p><h3>新生可以尝试的一步</h3><p>' + esc(learning.next) + '</p><a class="button secondary" href="#/practice/' + project.id + '">开始：' + esc(project.name) + icon('arrow') + '</a></section><div class="source-box"><div>' + icon('shield') + '<strong>来源与核对说明</strong></div><p>' + esc(person.verificationNote) + '</p></div></article><aside class="profile-aside"><div class="takeaway-card"><span class="section-kicker">TAKE A LITTLE INSPIRATION</span><h3>把启发变成一个行动</h3><p>' + esc(person.takeaway) + '</p><span class="editor-note">平台编辑提炼，非校友原话</span></div><div class="related-routes"><h3>选择自己的成长路线</h3>' + person.routes.map(id => { const route = routeById(id); return '<a href="#/paths/' + route.id + '"><span class="related-icon">' + icon(route.icon) + '</span><span>' + esc(route.name) + '<small>' + esc(route.duration) + ' · 可调整</small></span>' + icon('chevron') + '</a>'; }).join('') + '</div></aside></div>' + methodSection(learning.methodIds, '把这份启发用到今天') + '</div>';
  }
  function pathsPage() {
    return '<div class="container inner-page"><div class="page-heading">' + eyebrow('PASS IT FORWARD / 成长传承') + '<h1>传承向前的力量，写下自己的成长。</h1><p>为零基础新生准备：先比较方向，再按步骤完成第一轮探索。用一份自己的作品，为母校献礼。</p></div><section class="inheritance-intro"><div><span class="section-kicker">从商职出发，向自己的光前行</span><h2>每一种成长，都值得被看见。</h2><p>校友故事带来启发，学习与实践留下积累。方向由你选择，每一步都可以从小处开始。</p></div><img src="assets/starpath.svg" width="650" height="550" alt="商职星途原创插画：从学习、实践走向成长"></section>' + beginnerSection() + '<div class="route-grid route-grid-large">' + data.routes.map(routeCard).join('') + '</div><section class="section">' + sectionHead('CHOOSE YOUR FIRST STEP', '这三条路线，分别适合什么时候？', '可以从一个目标开始，之后再调整。') + '<div class="comparison-wrap" tabindex="0" role="region" aria-label="路线比较，窄屏可横向滚动"><table class="route-comparison"><caption class="sr-only">成长路线的目标、阶段与成果比较</caption><thead><tr><th scope="col">当前目标</th><th scope="col">行动顺序</th><th scope="col">最终留下</th></tr></thead><tbody>' + data.routes.map(route => '<tr><th scope="row"><a href="#/paths/' + route.id + '">' + esc(route.name) + '</a><small>' + esc(route.audience) + '</small></th><td>' + route.stages.map(stage => esc(stage.title)).join(' → ') + '</td><td>' + esc(route.outcome) + '</td></tr>').join('') + '</tbody></table></div></section>' + practiceSection() + methodSection(data.methodCards.map(method => method.id)) + '<div class="source-note">' + icon('info') + '<div><strong>第一轮探索，按自己的节奏来</strong><p>模板为平台建议，不代表校友本人路径，也不承诺获奖、录取或就业。核心内容可离线阅读，打开外部官方资料需要联网；Python 案例需要先准备本地工具。</p></div></div></div>';
  }
  function stageGuide(stage, index) {
    return '<details class="reading-details stage-guide" id="stage-' + index + '"' + (index === 0 ? ' open' : '') + '><summary><span class="stage-guide-number">0' + (index + 1) + '</span><span><small>' + esc(stage.period) + '</small><strong>' + esc(stage.title) + '</strong></span><span class="stage-task-count">' + stage.tasks.length + ' 项任务</span></summary><div class="reading-body"><p class="stage-purpose">' + esc(stage.why) + '</p><h3>开始前，认识这些基础</h3><p>' + esc(stage.preparation) + '</p><h3>这阶段的三个动作</h3>' + textList(stage.tasks, true) + '<h3>一步步怎么做</h3>' + textList(stage.steps, true) + exampleBlock(stage.example, '成果样例 · 平台示例') + '<div class="guide-check-grid"><div><h3>做到什么程度</h3>' + textList(stage.checklist) + '</div><div><h3>遇到困难怎么办</h3>' + textList(stage.pitfalls) + '</div></div><h3>对应资料与方法</h3>' + resourceCards(stage.resourceIds) + methodLinks(stage.methodIds) + '</div></details>';
  }
  function routePage(route) {
    const people = data.alumni.filter(person => person.routes.includes(route.id));
    const methods = [...new Set([...route.methodIds, ...route.stages.flatMap(stage => stage.methodIds)])];
    return '<div class="container inner-page"><a class="back-link" href="#/paths">' + icon('back') + '返回成长路线</a><section class="path-hero route-' + route.color + '"><div><span class="route-icon">' + icon(route.icon) + '</span><div class="eyebrow">零基础指南 · 平台建议</div><h1>' + esc(route.name) + '</h1><h2>' + esc(route.subtitle) + '</h2><p>' + esc(route.description) + '</p><div class="path-hero-meta"><span>' + icon('calendar') + esc(route.duration) + '</span><span>' + route.stages.length + ' 个阶段 · ' + taskCount(route) + ' 项初始任务</span></div></div><div class="path-create-card"><h3>让这条路线，为你而行</h3><p>' + esc(route.audience) + '</p><button class="button primary" data-action="create-plan" data-template="' + route.id + '">使用这条路线' + icon('arrow') + '</button><span>保存在本机 · 任务与日期均可修改</span></div></section><div class="route-outcome"><div><span class="section-kicker">这一轮，你会留下</span><strong>' + esc(route.outcome) + '</strong></div><p>' + esc(route.effort) + '。建议时长不会自动设置任务日期。</p></div><nav class="reading-toc" aria-label="路线阅读目录">' + route.stages.map((stage, index) => '<button data-action="scroll-to" data-value="stage-' + index + '">0' + (index + 1) + ' ' + esc(stage.title) + '</button>').join('') + '<button data-action="scroll-to" data-value="practice-library">实践案例</button><button data-action="scroll-to" data-value="methods">学习方法</button></nav><section class="section">' + sectionHead('ONE STEP AT A TIME', '走稳每一个阶段', '展开阅读具体步骤，完成后回到个人计划记录进度。') + '<div class="stage-guides">' + route.stages.map(stageGuide).join('') + '</div></section>' + practiceSection(route.projectIds, route.id === 'education' ? '可选体验：用程序整理模拟学习记录' : '与这条路线配套的实践案例') + methodSection(methods) + '<section class="section">' + sectionHead('STORIES TO INSPIRE', '也读读这些公开经历', '成长路线是平台设计，相关校友未必使用过这些方法或案例。') + '<div class="related-people">' + people.map(person => '<a href="#/alumni/' + person.id + '" class="related-person">' + personThumbnail(person) + '<span><strong>' + esc(person.name) + '</strong><small>' + esc(person.role) + '</small></span>' + icon('upRight') + '</a>').join('') + '</div></section></div>';
  }
  function practicePage(project) {
    return '<div class="container inner-page practice-page"><a class="back-link" href="#/paths">' + icon('back') + '返回成长路线</a><section class="practice-hero route-' + project.color + '"><div><span class="section-kicker">' + esc(project.category) + ' · 原创教学示例</span><h1>' + esc(project.name) + '</h1><p>' + esc(project.scenario) + '</p><div class="path-hero-meta"><span>' + esc(project.duration) + '</span></div><div class="practice-actions"><a class="button primary" href="' + esc(project.download) + '" download>' + icon('download') + '下载起始材料与成品</a><a class="button secondary" href="' + esc(project.preview) + '" target="_blank" rel="noopener">查看参考' + icon('upRight') + '</a></div></div><div class="practice-hero-result"><span>跟着做，得到一份自己的成果</span><strong>' + esc(project.outcome) + '</strong><p>先尝试，再对照；记录自己的修改和验证过程。</p></div></section><nav class="reading-toc" aria-label="案例阅读目录"><button data-action="scroll-to" data-value="practice-setup">准备环境</button><button data-action="scroll-to" data-value="practice-steps">分步练习</button><button data-action="scroll-to" data-value="practice-checks">排障与验收</button><button data-action="scroll-to" data-value="practice-resources">延伸资料</button></nav><div class="practice-reading"><section class="section" id="practice-setup">' + sectionHead('BEFORE YOU START', '先准备好，再动手', '首次安装工具需要联网；材料解压后可以保留在本地反复练习。') + '<div class="setup-card"><h3>Windows 操作准备</h3>' + textList(project.setup, true) + '</div><dl class="term-grid">' + project.terms.map(term => '<div><dt>' + esc(term[0]) + '</dt><dd>' + esc(term[1]) + '</dd></div>').join('') + '</dl></section><section class="section" id="practice-steps">' + sectionHead('MAKE SOMETHING REAL', '一步一步，看到结果', '每一步都先保存、运行和观察，再继续。') + project.steps.map((step, index) => '<details class="reading-details practice-step"' + (index === 0 ? ' open' : '') + '><summary><span class="stage-guide-number">0' + (index + 1) + '</span><strong>' + esc(step.title) + '</strong></summary><div class="reading-body"><p>' + esc(step.text) + '</p>' + (step.code ? exampleBlock(step.code, '代码或命令 · 可按教程使用') : '') + '<div class="expected-result"><strong>你应该看到</strong><p>' + esc(step.expected) + '</p></div></div></details>').join('') + '</section><section class="section" id="practice-checks">' + sectionHead('CHECK YOUR WORK', '做完，还要能验证', '逐项实际操作，记录预期和结果。') + '<div class="guide-check-grid"><div class="setup-card"><h3>验收清单</h3>' + textList(project.checks, true) + '</div><div class="setup-card"><h3>常见问题</h3><dl class="error-list">' + project.errors.map(error => '<dt>' + esc(error[0]) + '</dt><dd>' + esc(error[1]) + '</dd>').join('') + '</dl></div></div><div class="extension-card"><h3>完成后，再试一点变化</h3>' + textList(project.extensions) + '</div></section><section class="section" id="practice-resources">' + sectionHead('GO A LITTLE FURTHER', '延伸阅读，按需打开', '核心步骤已保存在本站，以下链接提供更完整的官方说明。') + resourceCards(project.resourceIds) + '</section></div>' + methodSection(project.methodIds) + '<section class="practice-next"><span class="section-kicker">KEEP GOING</span><h2>让这次练习，成为计划中的一步</h2><p>创建整条路线的计划后，可以编辑任务、目标与日期。案例不会自动判定任务完成。</p><div class="practice-actions">' + project.routeIds.map(id => '<button class="button secondary" data-action="create-plan" data-template="' + id + '">创建' + esc(routeById(id).name) + '计划</button>').join('') + '</div></section></div>';
  }
  function growthLearning(plan) {
    const route = plan && routeById(plan.templateId);
    const ids = route ? [...route.methodIds, 'project-readme', 'weekly-review'] : data.methodCards.map(method => method.id);
    return '<section class="growth-learning"><div class="growth-reading-entry"><div><span class="section-kicker">FROM CHECKLIST TO LEARNING</span><h2>完成之后，留下看得见的证据。</h2><p>参考项目说明与复盘模板，把文件、测试和下一步整理清楚。模板中的示例不会自动保存为个人记录。</p></div>' + (route ? '<a class="button secondary" href="#/paths/' + route.id + '">返回' + esc(route.name) + '学习指导' + icon('arrow') + '</a>' : '<a class="button secondary" href="#/practice/campus-guide">从网页案例开始' + icon('arrow') + '</a>') + '</div>' + methodSection(ids, '项目说明与复盘工具箱') + '</section>';
  }
  function localDate() {
    const now = new Date();
    return now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0');
  }
  function taskRow(task, planId) {
    const late = task.dueDate && task.dueDate < localDate() && !task.completed;
    return '<li class="task-row ' + (task.completed ? 'task-complete' : '') + '"><label class="task-check" for="task-' + task.id + '"><input id="task-' + task.id + '" type="checkbox" data-task="' + task.id + '" data-plan="' + planId + '" ' + (task.completed ? 'checked' : '') + '><span class="check-visual">' + icon('check') + '</span><span class="task-text">' + esc(task.title) + '</span></label><div class="task-row-actions">' + (task.dueDate ? '<span class="task-date ' + (late ? 'late' : '') + '">' + icon('calendar') + esc(task.dueDate) + (late ? '<small>待跟进</small>' : '') + '</span>' : '') + '<button class="icon-button" data-action="edit-task" data-plan="' + planId + '" data-task="' + task.id + '" aria-label="编辑任务：' + esc(task.title) + '">' + icon('edit') + '</button></div></li>';
  }
  function growthPage(planId) {
    const state = store.get();
    const plan = planId ? state.plans.find(item => item.id === planId) : state.plans[0];
    if (planId && !plan) return notFound('这份计划已不存在', '可能已被删除，或尚未导入到当前浏览器。', '#/growth', '返回我的成长');
    const allTasks = state.plans.flatMap(item => item.tasks);
    const completed = allTasks.filter(task => task.completed).length;
    const overall = allTasks.length ? Math.round(completed / allTasks.length * 100) : 0;
    const toolbar = '<div class="growth-tools"><button class="button secondary small" data-action="export">' + icon('download') + '导出备份</button><button class="button secondary small" data-action="import">' + icon('upload') + '导入备份</button></div>';
    let html = '<div class="container inner-page growth-page"><div class="page-heading growth-heading"><div>' + eyebrow('MY JOURNEY / 我的成长') + '<h1>每一个小小的完成，都算数。</h1><p>按照自己的节奏，把今天的行动连成明天的星途。</p></div>' + toolbar + '</div><div class="stats-grid"><div><span class="stat-label">我的成长计划</span><strong>' + state.plans.length + '<small>份</small></strong></div><div><span class="stat-label">已完成任务</span><strong>' + completed + '<small>/ ' + allTasks.length + '</small></strong></div><div><span class="stat-label">整体完成度</span><strong>' + overall + '<small>%</small></strong></div><div><span class="stat-label">收藏的校友</span><strong>' + state.favorites.length + '<small>位</small></strong></div></div>';
    if (!plan) {
      html += '<section class="empty-growth"><div class="empty-growth-art" aria-hidden="true"><div class="empty-orbit"></div>✦<span>YOUR NEXT STEP</span></div><div><span class="section-kicker">从一个小目标开始</span><h2>你的成长故事，等你写下第一笔。</h2><p>选择一条路线，或从空白计划开始。目标、任务与节奏，都由你决定。</p><div class="hero-actions"><a class="button primary" href="#/paths">选择成长路线' + icon('arrow') + '</a><button class="button secondary" data-action="create-plan" data-template="">创建空白计划</button></div></div></section>';
    } else {
      const progress = store.progress(plan);
      const template = routeById(plan.templateId);
      const stages = [...new Set(plan.tasks.map(task => task.stage))];
      html += '<div class="growth-layout"><aside class="plan-sidebar"><div class="sidebar-heading"><h2>我的计划</h2><span>' + state.plans.length + '</span></div><nav aria-label="成长计划">' + state.plans.map(item => { const p = store.progress(item); return '<a class="plan-tab ' + (item.id === plan.id ? 'selected' : '') + '" href="#/growth/' + item.id + '" ' + (item.id === plan.id ? 'aria-current="page"' : '') + '><strong>' + esc(item.title) + '</strong><span>' + p.complete + ' / ' + p.total + ' 项完成 <b>' + p.percent + '%</b></span><span class="mini-progress"><i style="width:' + p.percent + '%"></i></span></a>'; }).join('') + '</nav><a class="button secondary" href="#/paths">' + icon('plus') + '从路线新建计划</a><button class="text-button" data-action="create-plan" data-template="">创建空白计划</button></aside><section class="plan-detail" aria-labelledby="plan-title"><div class="plan-detail-heading"><div><span class="section-kicker">' + (template ? esc(template.name) + ' · 自定义成长计划' : '我的自定义计划') + '</span><h2 id="plan-title">' + esc(plan.title) + '</h2><p class="plan-goal">' + (plan.goal ? esc(plan.goal) : '写下你的目标，让每一步都有自己的方向。') + '</p></div><button class="icon-button" data-action="edit-plan" data-plan="' + plan.id + '" aria-label="编辑计划目标">' + icon('edit') + '</button></div><div class="plan-progress-summary"><span>' + progress.complete + ' / ' + progress.total + ' 项任务已完成</span><strong>' + progress.percent + '%</strong></div><div class="progress-track" role="progressbar" aria-label="当前计划完成度" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + progress.percent + '"><span style="width:' + progress.percent + '%"></span></div>' + (progress.total && progress.percent === 100 ? '<div class="completion-note">' + icon('spark') + '这份计划已全部完成。记得回顾收获，再决定下一步。</div>' : '') + '<div class="task-groups">' + (stages.length ? stages.map((stage, index) => '<section class="task-group"><div class="task-group-heading"><span>0' + (index + 1) + '</span><h3>' + esc(stage) + '</h3><small>' + plan.tasks.filter(task => task.stage === stage && task.completed).length + ' / ' + plan.tasks.filter(task => task.stage === stage).length + '</small></div><ul>' + plan.tasks.filter(task => task.stage === stage).map(task => taskRow(task, plan.id)).join('') + '</ul></section>').join('') : '<div class="empty-tasks"><span>' + icon('plus') + '</span><h3>从第一项任务开始</h3><p>把目标拆成具体行动，完成一步，就离目标更近一步。</p></div>') + '</div><div class="plan-bottom-actions"><button class="button secondary" data-action="add-task" data-plan="' + plan.id + '">' + icon('plus') + '添加任务</button><button class="text-button danger-text" data-action="delete-plan" data-plan="' + plan.id + '">删除计划</button></div></section></div>';
    }
    html += '<div class="local-note">' + icon('shield') + '<p>进度仅保存在当前浏览器，建议定期导出备份。更换浏览器、移动文件或清理浏览器数据后，可通过导入恢复。</p></div>';
    if (state.favorites.length) html += '<section class="section saved-people">' + sectionHead('KEEP THE INSPIRATION', '收藏的成长故事', '') + '<div class="related-people">' + state.favorites.map(personById).map(person => '<a class="related-person" href="#/alumni/' + person.id + '">' + personThumbnail(person) + '<span><strong>' + person.name + '</strong><small>' + person.role + '</small></span>' + icon('upRight') + '</a>').join('') + '</div></section>';
    html += growthLearning(plan);
    return html + '</div>';
  }
  function aboutPage() {
    const sources = [...new Map([data.anniversary.source, ...data.alumni.flatMap(person => person.sources), ...data.resources.map(resource => ({ ...resource, date: '延伸学习资料' }))].map(source => [source.url, source])).values()];
    return '<div class="container inner-page about-page"><div class="page-heading">' + eyebrow('ABOUT STARPATH') + '<h1>每一个故事，都有真实的出处。</h1><p>商职星途·九秩校庆，是连接校史、校友故事与个人成长的学生创作专题。</p></div><div class="about-sections"><section><h2>九秩校庆专题</h2><p>专题更新：2026-09-28。以1936—2026为纪念坐标，校史首版收录官方资料中的1936年办学溯源与1999年高职建校两个节点；资料日期按官网文件目录标注，不推断具体发布日期。</p><p>“2026·九秩同行”为本站纪念主题，不是官方活动公告。90周年数字与年轮主视觉为本项目原创设计，不是学校官方校庆标识。献礼行动为平台建议，由用户自行记录完成情况；原有校友、指南、实践材料和个人计划继续保留。</p></section><section><h2>关于这个项目</h2><p>我们希望把真实的校友成长经历变成可探索的故事，帮助你发现方向，再通过个人计划把启发转化为行动。本项目为学生创作，不是学校官方服务平台，也不代表校友本人观点。</p></section><section><h2>内容与图片</h2><p>人物经历依据学校公开报道整理，保留原文链接与报道日期。历史任职不代表当前任职，未披露的信息不作推断。人物导读与学习启发属于编辑提炼；成长路线属于平台建议，不承诺升学、获奖或就业结果。</p><p>校徽取自山东商业职业技术大学官网，使用原始标识的校徽部分。王宗宇、王功明和陈亮的照片来自下列官方人物介绍或讲座报道，保留原始文件，仅调整页面中的显示范围，未使用 AI 重绘人脸。石振邦暂用姓名图形，待取得可核实的本人照片后补充。星途插画为本项目原创。</p><p><a href="https://www.sict.edu.cn/" target="_blank" rel="noopener noreferrer">校徽来源：山东商业职业技术大学官网</a></p><ul class="source-list">' + sources.map(source => '<li><span>' + source.date + '</span><a href="' + source.url + '" target="_blank" rel="noopener noreferrer">' + source.title + icon('upRight') + '</a></li>').join('') + '</ul></section><section><h2>实践内容与更新说明</h2><p>学习内容更新：2026-09-26。三条路线、三个实践案例与六张方法卡为平台原创教学设计。校园问答与学习记录均为模拟数据，不是学校正式通知或真实学生资料。路线时长仅为首轮探索参考。</p><p>人物档案保留原有官方出处；2026-09-26内容深化时未能重新读取母校报道，未新增未经核实的人物经历。北京工业大学教师主页已复核博士、博士后和教学科研阶段；历史页面不能用来断言当前任职。事实、平台分析与学习建议在详情页分别标注。</p></section><section><h2>你的数据，由你保管</h2><p>无需注册。收藏和成长计划保存在当前浏览器，不会上传到服务器。清理浏览器数据、使用隐私模式、更换浏览器或移动网页文件可能影响保存。建议在“我的成长”定期导出 JSON 备份，换环境后可导入恢复。</p><p>网页的核心功能、指南和练习材料都在本地，主动打开学校报道或官方学习资料时才访问外部网站。Python 实践需先安装本地工具，首次安装需要联网。</p><a href="#/growth" class="button secondary">管理我的成长数据' + icon('arrow') + '</a></section></div></div>';
  }
  function notFound(title = '这段星途，暂时还没找到。', text = '链接可能已失效，回到探索页重新出发吧。', href = '#/alumni', label = '返回校友探索') {
    return '<div class="container inner-page"><div class="empty-state not-found"><span class="empty-icon">' + icon('compass') + '</span><h1>' + title + '</h1><p>' + text + '</p><a class="button primary" href="' + href + '">' + label + icon('arrow') + '</a></div></div>';
  }
  function clearPageTransition() {
    clearTimeout(pageSnapshotTimer);
    if (pageSnapshot) pageSnapshot.remove();
    pageSnapshot = null;
  }
  function captureOutgoingPage() {
    const bounds = main.getBoundingClientRect();
    const headerBottom = document.querySelector('.site-header').getBoundingClientRect().bottom;
    const top = Math.max(0, bounds.top, headerBottom);
    const bottom = Math.min(window.innerHeight, bounds.bottom);
    if (!main.firstElementChild || bottom <= top) return;

    // Keep only the visible old content; it never receives input or accessibility focus.
    const snapshot = document.createElement('div');
    snapshot.className = 'page-transition-snapshot';
    snapshot.setAttribute('aria-hidden', 'true');
    snapshot.setAttribute('inert', '');
    snapshot.style.top = top + 'px';
    snapshot.style.left = bounds.left + 'px';
    snapshot.style.width = bounds.width + 'px';
    snapshot.style.height = (bottom - top) + 'px';
    const position = document.createElement('div');
    position.className = 'page-transition-position';
    position.style.top = (bounds.top - top) + 'px';
    const content = main.firstElementChild.cloneNode(true);
    content.classList.remove('page-enter');
    content.removeAttribute('id');
    content.querySelectorAll('[id]').forEach(node => node.removeAttribute('id'));
    content.querySelectorAll('a,button,input,select,textarea,[tabindex]').forEach(node => node.setAttribute('tabindex', '-1'));
    position.appendChild(content);
    snapshot.appendChild(position);
    document.body.appendChild(snapshot);
    pageSnapshot = snapshot;
    snapshot.addEventListener('animationend', event => {
      if (event.target === snapshot && pageSnapshot === snapshot) clearPageTransition();
    });
    // Also clean up if animations are disabled or the browser skips animationend.
    pageSnapshotTimer = setTimeout(clearPageTransition, 400);
  }
  function render(options = {}) {
    if (location.hash === '#main') { main.focus(); return; }
    clearPageTransition();
    let parts;
    try { parts = decodeURIComponent(location.hash.replace(/^#\/?/, '')).split('/').filter(Boolean); }
    catch (_) { parts = ['invalid']; }
    const page = parts[0] || 'home';
    const id = parts[1];
    const route = parts.length ? parts.join('/') : 'home';
    const animatePage = options.routeChange && renderedRoute !== null && route !== renderedRoute && !reducedMotion.matches;
    current = { page, id };
    let content;
    let title = '校庆首页';
    if (parts.length > 2) content = notFound();
    else if (page === 'home' && !id) content = home();
    else if (page === 'history' && !id) { title = '九秩校史'; content = historyPage(); }
    else if (page === 'alumni') { title = '校友风采'; content = id ? (personById(id) ? personPage(personById(id)) : notFound()) : alumniPage(); }
    else if (page === 'paths') { title = '成长传承'; content = id ? (routeById(id) ? routePage(routeById(id)) : notFound('没有找到这条路线', '请从现有路线中选择一个方向。', '#/paths', '查看成长路线')) : pathsPage(); }
    else if (page === 'practice') { title = '入门实践'; content = id && projectById(id) ? practicePage(projectById(id)) : notFound('没有找到这个实践案例', '请从成长路线选择一个案例。', '#/paths', '查看成长路线'); }
    else if (page === 'growth') { title = '我的成长'; content = growthPage(id); }
    else if (page === 'about' && !id) { title = '内容来源与使用说明'; content = aboutPage(); }
    else content = notFound();
    if (modal.open && !options.keepModal) modal.close();
    if (animatePage) captureOutgoingPage();
    main.innerHTML = content;
    if (page === 'alumni' && !id) updateAlumniResults();
    if (animatePage) main.firstElementChild.classList.add('page-enter');
    renderedRoute = route;
    document.title = title + ' · 商职星途 · 九秩校庆';
    document.querySelectorAll('[data-nav]').forEach(link => {
      if (link.dataset.nav === (page === 'practice' ? 'paths' : page)) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
    if (!options.keepScroll) window.scrollTo({ top: 0, behavior: 'instant' });
    if (options.focusSelector) { const node = main.querySelector(options.focusSelector); if (node) node.focus({ preventScroll: true }); }
    else if (options.focusId) { const node = document.getElementById(options.focusId); if (node) node.focus({ preventScroll: true }); }
    else if (options.routeChange) main.focus({ preventScroll: true });
    notice();
  }
  function openModal(title, body) {
    modalReturnFocus = document.activeElement;
    modalContent.innerHTML = '<div class="modal-heading"><h2 id="modal-title">' + title + '</h2><button class="icon-button" data-action="close-modal" aria-label="关闭对话框">' + icon('close') + '</button></div>' + body;
    modal.showModal();
    document.body.classList.add('modal-open');
    const field = modal.querySelector('[autofocus]');
    if (field) field.focus();
  }
  const modalError = '<p id="modal-error" class="form-error" role="alert" hidden></p>';
  const modalActions = (label = '保存', extra = '') => '<div class="modal-actions">' + extra + '<button class="button secondary" type="button" data-action="close-modal">取消</button><button class="button primary" type="submit">' + label + '</button></div>';
  function openCreate(templateId, tribute = false) {
    const template = routeById(templateId);
    const preset = tribute ? data.anniversary.tribute : null;
    const existing = store.get().plans.filter(plan => plan.templateId === templateId).length;
    const title = preset ? preset.title : template ? '我的' + template.name + '计划' : '我的成长计划';
    const description = preset ? '将创建一份包含三个献礼行动的独立计划。创建后可以修改任务、日期和完成状态；已有计划保持不变。' : template ? '将创建一份包含' + template.stages.length + '个阶段、' + taskCount(template) + '项任务的个人计划。你可以自由编辑目标、任务和日期。' : '从一个明确的小目标开始，随后为它添加具体任务。';
    const preview = preset ? '<ol class="tribute-task-preview">' + preset.tasks.map(task => '<li><strong>' + esc(task.stage) + '</strong><span>' + esc(task.title) + '</span></li>').join('') + '</ol><p class="inline-note">行动为平台建议，由你自行记录完成情况。每次提交都会新建一份计划。</p>' : '';
    openModal(preset ? '开启我的校庆献礼计划' : template ? '开始我的' + template.name + '路线' : '新建成长计划', '<form data-form="create-plan"' + (preset ? ' data-preset="tribute"' : '') + '><input type="hidden" name="templateId" value="' + esc(templateId || '') + '"><p class="modal-description">' + description + '</p>' + preview + (existing && template ? '<p class="inline-note">你已有 ' + existing + ' 份同类路线计划，这次会创建独立的新计划。</p>' : '') + '<label class="form-field">计划名称<input name="title" required maxlength="120" value="' + esc(title) + '" autofocus></label><label class="form-field">我的目标 <span class="field-optional">选填</span><textarea name="goal" rows="3" maxlength="1000" placeholder="例如：完成一个可以给同学演示的小项目">' + esc(preset ? preset.goal : '') + '</textarea></label>' + modalError + modalActions('创建计划') + '</form>');
  }
  function openPlanEdit(planId) {
    const plan = store.get().plans.find(item => item.id === planId);
    if (!plan) throw new Error('这份计划已不存在。');
    openModal('编辑我的成长目标', '<form data-form="edit-plan" data-plan="' + planId + '"><label class="form-field">计划名称<input name="title" required maxlength="120" value="' + esc(plan.title) + '" autofocus></label><label class="form-field">我的目标<textarea name="goal" rows="4" maxlength="1000" placeholder="写下你希望通过这份计划实现什么">' + esc(plan.goal) + '</textarea></label>' + modalError + modalActions() + '</form>');
  }
  function openTaskEdit(planId, taskId) {
    const plan = store.get().plans.find(item => item.id === planId);
    if (!plan) throw new Error('这份计划已不存在。');
    const task = taskId ? plan.tasks.find(item => item.id === taskId) : null;
    if (taskId && !task) throw new Error('这项任务已不存在。');
    if (!task && plan.tasks.length >= 100) throw new Error('每份计划最多支持100项任务，请先整理现有任务。');
    const stages = [...new Set(plan.tasks.map(item => item.stage))];
    openModal(task ? '编辑这一步' : '添加一个小目标', '<form data-form="task" data-plan="' + planId + '" data-task="' + esc(taskId || '') + '"><label class="form-field">任务内容<input name="title" required maxlength="180" value="' + esc(task ? task.title : '') + '" placeholder="一个具体、可以完成的行动" autofocus></label><div class="form-row"><label class="form-field">所属阶段<input name="stage" list="stage-options" maxlength="80" required value="' + esc(task ? task.stage : stages[stages.length - 1] || '我的行动') + '"><datalist id="stage-options">' + stages.map(stage => '<option value="' + esc(stage) + '"></option>').join('') + '</datalist></label><label class="form-field">目标日期 <span class="field-optional">选填</span><input type="date" name="dueDate" min="1900-01-01" max="9999-12-31" value="' + esc(task ? task.dueDate : '') + '"></label></div>' + modalError + modalActions(task ? '保存修改' : '添加任务', task ? '<button type="button" class="text-button danger-text" data-action="delete-task" data-plan="' + planId + '" data-task="' + task.id + '">删除任务</button>' : '') + '</form>');
  }
  function download(text, name) {
    const url = URL.createObjectURL(new Blob([text], { type: 'application/json;charset=utf-8' }));
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  function refreshFavorites() {
    const activePerson = document.activeElement?.dataset.person;
    const favorites = store.get().favorites;
    document.querySelectorAll('[data-action="favorite"]').forEach(button => {
      const person = personById(button.dataset.person);
      const active = favorites.includes(person.id);
      button.classList.toggle('is-favorite', active);
      button.setAttribute('aria-pressed', String(active));
      button.setAttribute('aria-label', (active ? '取消收藏' : '收藏') + person.name);
      button.title = active ? '取消收藏' : '收藏校友';
    });
    if (current.page === 'alumni' && !current.id) {
      updateAlumniResults();
      if (activePerson) {
        const nextFocus = main.querySelector('[data-action="favorite"][data-person="' + activePerson + '"]') || document.getElementById('alumni-query');
        nextFocus?.focus({ preventScroll: true });
      }
    }
  }
  function errorMessage(error) {
    const target = modal.open && document.getElementById('modal-error');
    if (target) { target.hidden = false; target.textContent = error.message || '操作未完成，请重试。'; }
    else toast(error.message || '操作未完成，请重试。');
  }
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-action]');
    if (!button) return;
    const { action, person, value, template, plan, task } = button.dataset;
    try {
      if (action === 'scroll-to') {
        const target = document.getElementById(value);
        if (target) {
          if (target.tagName === 'DETAILS') target.open = true;
          const focusTarget = target.tagName === 'DETAILS' ? target.querySelector('summary') : target;
          if (focusTarget === target) target.setAttribute('tabindex', '-1');
          focusTarget.focus({ preventScroll: true });
          target.scrollIntoView({ behavior: reducedMotion.matches ? 'instant' : 'smooth', block: 'start' });
        }
      }
      else if (action === 'favorite') { const persisted = store.toggleFavorite(person); refreshFavorites(); saved(persisted, store.get().favorites.includes(person) ? '已收藏这个成长故事' : '已取消收藏'); }
      else if (action === 'filter-favorites') { filters.favorites = !filters.favorites; render({ keepScroll: true }); main.querySelector('[data-action="filter-favorites"]').focus({ preventScroll: true }); }
      else if (action === 'filter-direction') { filters.direction = value; document.querySelectorAll('[data-action="filter-direction"]').forEach(chip => { chip.classList.toggle('active', chip.dataset.value === value); chip.setAttribute('aria-pressed', String(chip.dataset.value === value)); }); updateAlumniResults(); }
      else if (action === 'reset-filters') { Object.assign(filters, { query: '', field: 'all', direction: 'all', favorites: false }); render({ keepScroll: true, focusId: 'alumni-query' }); }
      else if (action === 'create-plan') openCreate(template || null);
      else if (action === 'create-tribute') openCreate(null, true);
      else if (action === 'edit-plan') openPlanEdit(plan);
      else if (action === 'add-task') openTaskEdit(plan);
      else if (action === 'edit-task') openTaskEdit(plan, task);
      else if (action === 'close-modal') modal.close();
      else if (action === 'delete-plan') {
        const entry = store.get().plans.find(item => item.id === plan);
        openModal('删除这份成长计划？', '<form data-form="delete-plan" data-plan="' + plan + '"><p class="modal-description">将移除「' + esc(entry.title) + '」及其中的任务。需要保留时，请先导出备份。</p>' + modalError + modalActions('确认删除') + '</form>');
      } else if (action === 'delete-task') {
        const entry = store.get().plans.find(item => item.id === plan).tasks.find(item => item.id === task);
        openModal('删除这项任务？', '<form data-form="delete-task" data-plan="' + plan + '" data-task="' + task + '"><p class="modal-description">' + esc(entry.title) + '</p>' + modalError + modalActions('确认删除') + '</form>');
      } else if (action === 'export') { download(store.exportBackup(), '商职星途-成长备份-' + localDate() + '.json'); toast('已发起备份下载，请检查浏览器下载记录'); }
      else if (action === 'export-raw') { download(store.damagedRaw() || '', '商职星途-原始记录.json'); toast('已发起原始记录下载'); }
      else if (action === 'import') { fileInput.value = ''; fileInput.click(); }
    } catch (error) { errorMessage(error); }
  });
  main.addEventListener('input', event => { if (event.target.id === 'alumni-query') { filters.query = event.target.value; updateAlumniResults(); } });
  main.addEventListener('change', event => {
    const target = event.target;
    try {
      if (target.id === 'field-filter') { filters.field = target.value; updateAlumniResults(); }
      else if (target.matches('input[type="checkbox"][data-task]')) {
        const persisted = store.editPlan(target.dataset.plan, plan => { const task = plan.tasks.find(item => item.id === target.dataset.task); if (!task) throw new Error('这项任务已不存在。'); task.completed = target.checked; });
        render({ keepScroll: true, focusId: target.id });
        saved(persisted, target.checked ? '又向前走了一步，任务已完成' : '已将任务恢复为未完成');
      }
    } catch (error) { errorMessage(error); render({ keepScroll: true }); }
  });
  modal.addEventListener('submit', event => {
    event.preventDefault();
    const form = event.target;
    const values = new FormData(form);
    const formType = form.dataset.form;
    const title = String(values.get('title') || '').trim();
    try {
      if (['create-plan', 'edit-plan', 'task'].includes(formType) && !title) throw new Error('请填写内容，不能只输入空格。');
      let persisted;
      if (formType === 'create-plan') {
        const tribute = form.dataset.preset === 'tribute';
        const details = { title, goal: String(values.get('goal') || '').trim() };
        if (tribute) details.initialTasks = data.anniversary.tribute.tasks.map(task => ({ title: task.title, stage: task.stage }));
        const result = store.createPlan(tribute ? null : values.get('templateId') || null, details);
        persisted = result.persisted;
        modal.close();
        location.hash = '/growth/' + result.id;
        saved(persisted, '成长计划已创建，第一步从现在开始');
        return;
      }
      if (formType === 'edit-plan') persisted = store.editPlan(form.dataset.plan, plan => { plan.title = title; plan.goal = String(values.get('goal') || '').trim(); });
      else if (formType === 'task') {
        const stage = String(values.get('stage') || '').trim();
        if (!stage) throw new Error('请填写所属阶段。');
        persisted = store.editPlan(form.dataset.plan, plan => {
          const fields = { title, stage, dueDate: String(values.get('dueDate') || '') };
          if (form.dataset.task) { const task = plan.tasks.find(item => item.id === form.dataset.task); if (!task) throw new Error('这项任务已不存在。'); Object.assign(task, fields); }
          else { if (plan.tasks.length >= 100) throw new Error('每份计划最多支持100项任务。'); plan.tasks.push({ id: store.uid(), ...fields, completed: false }); }
        });
      } else if (formType === 'delete-plan') {
        persisted = store.deletePlan(form.dataset.plan);
        modal.close();
        if (location.hash === '#/growth') render({ keepScroll: true, routeChange: true }); else location.hash = '/growth';
        saved(persisted, '已删除这份计划');
        return;
      } else if (formType === 'delete-task') persisted = store.editPlan(form.dataset.plan, plan => { plan.tasks = plan.tasks.filter(task => task.id !== form.dataset.task); });
      else if (formType === 'import') {
        if (!pendingImport) throw new Error('没有可导入的数据，请重新选择文件。');
        persisted = store.replace(pendingImport);
        pendingImport = null;
        modal.close();
        if (location.hash === '#/growth') render({ routeChange: true }); else location.hash = '/growth';
        saved(persisted, '备份已恢复');
        return;
      } else throw new Error('未识别的操作。');
      modal.close();
      const focusSelector = formType === 'edit-plan' ? '[data-action="edit-plan"]' : formType === 'task' && form.dataset.task ? '[data-action="edit-task"][data-task="' + form.dataset.task + '"]' : '[data-action="add-task"]';
      render({ keepScroll: true, focusSelector });
      saved(persisted, formType === 'delete-task' ? '已删除任务' : '修改已保存');
    } catch (error) { errorMessage(error); }
  });
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files[0];
    if (!file) return;
    try {
      if (file.size > 1024 * 1024) throw new Error('请选择不超过1 MB的备份文件。');
      const imported = store.parseBackup(await file.text());
      pendingImport = imported;
      const tasks = imported.plans.flatMap(plan => plan.tasks);
      const existing = store.get();
      openModal('确认恢复这份备份？', '<form data-form="import"><p class="modal-description">请先核对内容。导入会替换当前的 ' + existing.plans.length + ' 份计划与 ' + existing.favorites.length + ' 位校友收藏，不会与现有记录合并。</p><div class="import-summary"><div><strong>' + imported.plans.length + '</strong><span>成长计划</span></div><div><strong>' + tasks.length + '</strong><span>任务</span></div><div><strong>' + imported.favorites.length + '</strong><span>校友收藏</span></div></div><ul class="import-plan-list">' + imported.plans.map(plan => '<li>' + esc(plan.title) + '<span>' + store.progress(plan).percent + '%</span></li>').join('') + '</ul><p class="inline-note">建议先导出现有记录，确认后再恢复备份。</p>' + modalError + modalActions('确认替换并恢复', '<button type="button" class="text-button" data-action="export">导出现有记录</button>') + '</form>');
    } catch (error) { pendingImport = null; toast(error.message || '无法读取文件，现有记录未作更改。'); }
    finally { fileInput.value = ''; }
  });
  modal.addEventListener('close', () => {
    document.body.classList.remove('modal-open');
    pendingImport = null;
    if (modalReturnFocus && modalReturnFocus.isConnected) modalReturnFocus.focus({ preventScroll: true });
  });
  modal.addEventListener('click', event => { if (event.target === modal) { const rect = modal.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) modal.close(); } });
  window.addEventListener('starpath:change', notice);
  window.addEventListener('hashchange', () => render({ routeChange: true }));
  document.querySelector('.skip-link').addEventListener('click', event => { event.preventDefault(); main.focus(); main.scrollIntoView(); });
  render();
})();
