'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '../project');
function load(raw, blocked = false) {
  const saved = new Map(raw === undefined ? [] : [['shangzhi-starpath:v1', raw]]);
  const context = vm.createContext({
    window: { dispatchEvent() {} },
    CustomEvent: class { constructor(type, detail) { this.type = type; this.detail = detail; } },
    localStorage: {
      getItem(key) { if (blocked) throw new Error('Unavailable'); return saved.get(key) ?? null; },
      setItem(key, value) { if (blocked) throw new Error('Unavailable'); saved.set(key, value); },
      removeItem(key) { saved.delete(key); }
    }
  });
  for (const name of ['data', 'learning', 'storage']) vm.runInContext(fs.readFileSync(path.join(root, 'js', name + '.js'), 'utf8'), context);
  return { ...context.window.StarPath, saved };
}
const plain = value => JSON.parse(JSON.stringify(value));
function oldState() {
  return { version: 1, favorites: ['wang-zongyu'], plans: [{ id: 'old-plan', templateId: 'competition', title: '旧计划', goal: '保留旧任务', createdAt: '2026-01-01T00:00:00.000Z', updatedAt: '2026-01-02T00:00:00.000Z', tasks: [{ id: 'old-task', title: '原来写下的任务', stage: '原阶段', dueDate: '2026-10-01', completed: true }] }] };
}
test('36 concrete tasks, complete guides, and all content references resolve', () => {
  const { data } = load();
  assert.equal(data.alumni.length, 4);
  assert.equal(data.routes.length, 3);
  assert.equal(data.practiceProjects.length, 3);
  assert.equal(data.methodCards.length, 6);
  const methods = new Set(data.methodCards.map(item => item.id));
  const resources = new Set(data.resources.map(item => item.id));
  const projects = new Set(data.practiceProjects.map(item => item.id));
  const routes = new Set(data.routes.map(item => item.id));
  let tasks = 0;
  for (const route of data.routes) {
    assert.equal(route.stages.length, 4);
    route.projectIds.forEach(id => assert.ok(projects.has(id)));
    for (const stage of route.stages) {
      assert.equal(stage.tasks.length, 3);
      tasks += stage.tasks.length;
      for (const field of ['why', 'preparation', 'example']) assert.ok(stage[field].trim().length > 15);
      for (const field of ['steps', 'checklist', 'pitfalls']) assert.ok(stage[field].length >= 2);
      stage.methodIds.forEach(id => assert.ok(methods.has(id)));
      stage.resourceIds.forEach(id => assert.ok(resources.has(id)));
    }
  }
  assert.equal(tasks, 36);
  for (const project of data.practiceProjects) {
    for (const field of ['download', 'preview']) assert.ok(fs.existsSync(path.join(root, project[field])));
    project.methodIds.forEach(id => assert.ok(methods.has(id)));
    project.routeIds.forEach(id => assert.ok(routes.has(id)));
    project.resourceIds.forEach(id => assert.ok(resources.has(id)));
    assert.ok(project.steps.every(step => step.expected && step.text));
  }
  for (const person of data.alumni) {
    assert.ok(projects.has(person.learning.projectId));
    assert.ok(person.timeline.every(event => person.sources.some(source => source.url === event.source.url)));
  }
});
test('existing v1 plans and backups retain their original tasks and progress', () => {
  const old = oldState();
  const { store, saved } = load(JSON.stringify(old));
  assert.deepEqual(plain(store.get()), old);
  assert.equal(store.progress(store.get().plans[0]).percent, 100);
  assert.deepEqual(plain(store.parseBackup(JSON.stringify({ app: 'shangzhi-starpath', ...old }))), old);
  const created = store.createPlan('competition');
  assert.equal(store.get().plans.find(plan => plan.id === created.id).tasks.length, 12);
  assert.deepEqual(plain(store.get().plans.find(plan => plan.id === 'old-plan')), old.plans[0]);
  assert.equal(JSON.parse(saved.get(store.key)).version, 1);
});
test('all new templates generate 12 editable tasks; empty plans remain empty', () => {
  const { data, store } = load();
  for (const route of data.routes) {
    const created = store.createPlan(route.id);
    const plan = store.get().plans.find(item => item.id === created.id);
    assert.equal(plan.tasks.length, 12);
    assert.equal(new Set(plan.tasks.map(task => task.stage)).size, 4);
    assert.equal(plan.tasks.filter(task => task.dueDate).length, 0);
    store.editPlan(plan.id, item => { item.tasks[0].title = '自定义'; item.tasks[0].completed = true; });
    assert.equal(store.get().plans.find(item => item.id === plan.id).tasks[0].title, '自定义');
  }
  const empty = store.createPlan(null);
  assert.equal(store.get().plans.find(plan => plan.id === empty.id).tasks.length, 0);
});
test('invalid backup and invalid edits leave state unchanged', () => {
  const { store } = load(JSON.stringify(oldState()));
  const before = plain(store.get());
  for (const text of ['{', '{}', JSON.stringify({ app: 'other', ...before }), JSON.stringify({ app: 'shangzhi-starpath', ...before, version: 2 })]) {
    assert.throws(() => store.parseBackup(text));
    assert.deepEqual(plain(store.get()), before);
  }
  assert.throws(() => store.editPlan('old-plan', plan => { plan.tasks[0].dueDate = '2026-02-30'; }));
  assert.deepEqual(plain(store.get()), before);
});
test('unavailable and damaged storage preserve the recovery behavior', () => {
  const session = load(undefined, true).store;
  assert.equal(session.status(), 'session');
  assert.equal(session.createPlan('career').persisted, false);
  assert.equal(session.get().plans[0].tasks.length, 12);
  assert.equal(JSON.parse(session.exportBackup()).plans.length, 1);
  const damaged = load('{broken').store;
  assert.equal(damaged.status(), 'damaged');
  assert.equal(damaged.damagedRaw(), '{broken');
  damaged.createPlan('education');
  assert.equal(damaged.damagedRaw(), '{broken');
  damaged.replace(oldState());
  assert.equal(damaged.status(), 'persistent');
  assert.equal(damaged.damagedRaw(), null);
});
