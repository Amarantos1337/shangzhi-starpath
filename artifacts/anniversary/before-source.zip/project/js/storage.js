(function () {
  'use strict';
  const app = window.StarPath;
  const KEY = 'shangzhi-starpath:v1';
  const alumniIds = new Set(app.data.alumni.map(person => person.id));
  const routeIds = new Set(app.data.routes.map(route => route.id));
  const empty = () => ({ version: 1, favorites: [], plans: [] });
  let state = empty();
  let status = 'persistent';
  let damagedRaw = null;
  const copy = value => JSON.parse(JSON.stringify(value));
  const fail = message => { throw new Error(message); };
  const object = value => value && typeof value === 'object' && !Array.isArray(value);
  function str(value, label, max, allowEmpty = false) {
    if (typeof value !== 'string' || value.length > max || (!allowEmpty && !value.trim())) fail(label + '格式不正确。');
    return value.trim();
  }
  function id(value) {
    if (typeof value !== 'string' || !/^[a-zA-Z0-9_-]{1,100}$/.test(value)) fail('记录编号格式不正确。');
    return value;
  }
  function date(value) {
    if (value === '') return '';
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) fail('任务日期格式不正确。');
    const parsed = new Date(value + 'T00:00:00.000Z');
    if (!Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value || value < '1900-01-01' || value > '9999-12-31') fail('任务日期无效。');
    return value;
  }
  function timestamp(value) {
    if (typeof value !== 'string' || value.length > 40 || !Number.isFinite(Date.parse(value))) fail('记录时间无效。');
    return value;
  }
  function validate(value) {
    if (!object(value) || value.version !== 1) fail('不支持此数据格式或版本，请选择商职星途导出的备份。');
    if (!Array.isArray(value.favorites) || value.favorites.length > alumniIds.size || value.favorites.some(item => !alumniIds.has(item))) fail('收藏数据无效。');
    if (!Array.isArray(value.plans) || value.plans.length > 20) fail('计划数据无效，最多支持20份计划。');
    const seenPlans = new Set();
    const plans = value.plans.map(plan => {
      if (!object(plan)) fail('计划格式无效。');
      const planId = id(plan.id);
      if (seenPlans.has(planId)) fail('计划编号重复。');
      seenPlans.add(planId);
      if (plan.templateId !== null && !routeIds.has(plan.templateId)) fail('计划模板无效。');
      if (!Array.isArray(plan.tasks) || plan.tasks.length > 100) fail('每份计划最多支持100项任务。');
      const seenTasks = new Set();
      const tasks = plan.tasks.map(task => {
        if (!object(task)) fail('任务格式无效。');
        const taskId = id(task.id);
        if (seenTasks.has(taskId)) fail('任务编号重复。');
        seenTasks.add(taskId);
        if (typeof task.completed !== 'boolean') fail('任务状态无效。');
        return { id: taskId, title: str(task.title, '任务名称', 180), stage: str(task.stage, '阶段名称', 80), dueDate: date(task.dueDate), completed: task.completed };
      });
      return { id: planId, templateId: plan.templateId, title: str(plan.title, '计划名称', 120), goal: str(plan.goal, '成长目标', 1000, true), createdAt: timestamp(plan.createdAt), updatedAt: timestamp(plan.updatedAt), tasks };
    });
    return { version: 1, favorites: [...new Set(value.favorites)], plans };
  }
  try {
    const raw = localStorage.getItem(KEY);
    if (raw !== null) {
      try { state = validate(JSON.parse(raw)); }
      catch (_) { status = 'damaged'; damagedRaw = raw; }
    }
    if (status !== 'damaged') {
      const probe = KEY + ':availability';
      localStorage.setItem(probe, '1');
      localStorage.removeItem(probe);
    }
  } catch (_) { status = 'session'; }

  function save() {
    if (status === 'damaged') return false;
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
      status = 'persistent';
      return true;
    } catch (_) { status = 'session'; return false; }
  }
  function update(change) {
    const draft = copy(state);
    change(draft);
    state = validate(draft);
    const persisted = save();
    window.dispatchEvent(new CustomEvent('starpath:change', { detail: { persisted } }));
    return persisted;
  }
  function uid() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
    return 'p-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 12);
  }
  function progress(plan) {
    const total = plan.tasks.length;
    const complete = plan.tasks.filter(task => task.completed).length;
    return { total, complete, percent: total ? Math.round(complete / total * 100) : 0 };
  }
  app.store = {
    key: KEY,
    get: () => copy(state),
    status: () => status,
    damagedRaw: () => damagedRaw,
    uid, progress, update,
    validate,
    parseBackup(text) {
      if (typeof text !== 'string' || text.length > 1024 * 1024) fail('请选择不超过1 MB的备份文件。');
      let value;
      try { value = JSON.parse(text); } catch (_) { fail('文件不是有效的 JSON，现有记录未作更改。'); }
      if (!object(value) || value.app !== 'shangzhi-starpath') fail('这不是商职星途导出的备份文件。');
      return validate(value);
    },
    exportBackup: () => JSON.stringify({ app: 'shangzhi-starpath', exportedAt: new Date().toISOString(), ...state }, null, 2),
    replace(value) {
      state = validate(value);
      damagedRaw = null;
      status = 'session';
      const persisted = save();
      window.dispatchEvent(new CustomEvent('starpath:change', { detail: { persisted } }));
      return persisted;
    },
    toggleFavorite(personId) {
      if (!alumniIds.has(personId)) fail('未找到这位校友。');
      return update(draft => { draft.favorites = draft.favorites.includes(personId) ? draft.favorites.filter(value => value !== personId) : [...draft.favorites, personId]; });
    },
    createPlan(templateId, details = {}) {
      if (state.plans.length >= 20) fail('最多可保存20份计划，请先整理已有计划。');
      const template = app.data.routes.find(route => route.id === templateId);
      if (templateId !== null && !template) fail('未找到这条路线。');
      const now = new Date().toISOString();
      const plan = { id: uid(), templateId, title: details.title ?? (template ? '我的' + template.name + '计划' : '我的成长计划'), goal: details.goal ?? '', createdAt: now, updatedAt: now,
        tasks: template ? template.stages.flatMap(stage => stage.tasks.map(title => ({ id: uid(), title, stage: stage.title, dueDate: '', completed: false }))) : [] };
      const persisted = update(draft => { draft.plans.unshift(plan); });
      return { id: plan.id, persisted };
    },
    editPlan(planId, change) {
      return update(draft => {
        const plan = draft.plans.find(item => item.id === planId);
        if (!plan) fail('这份计划已不存在。');
        change(plan);
        plan.updatedAt = new Date().toISOString();
      });
    },
    deletePlan(planId) { return update(draft => { draft.plans = draft.plans.filter(plan => plan.id !== planId); }); }
  };
})();
