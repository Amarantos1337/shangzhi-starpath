# 商职星途

面向计算机与信息类零基础新生的校友探索与成长指南。无需安装依赖，直接打开 `project/index.html` 即可使用。

## 内容

- 4 份校友档案：公开经历逐项关联来源，平台分析与资料边界单独呈现。
- 3 条成长指南：每条 4 个阶段、12 项任务，包含准备、操作、样例、验收与排障。
- 3 个实践案例：校园指南网页、Python 学习时间统计、本地 HTTP 服务排障。
- 6 张方法卡：任务拆解、错误求助、信息核实、项目说明、作品演示、每周复盘。

首页“零基础从这里开始”进入网页案例。实践详情可下载 ZIP，包含起始文件、参考成品及说明；解压后使用。Python 案例需要单独安装 Python 3，网站本身不需要 Python。

## 本地预览

```powershell
python -m http.server 8765 --bind 127.0.0.1 --directory project
```

打开 `http://127.0.0.1:8765/`。直接双击 HTML 与 HTTP 预览均受支持。不同地址的浏览器存储相互独立，转移记录可使用 JSON 备份。

## 内容维护

- `project/js/data.js`：原始人物资料与稳定路线 ID。
- `project/js/learning.js`：指南、实践、方法卡、官方资源、人物编辑分析，均挂在 `window.StarPath.data`。
- `project/js/storage.js`：版本 1 本地记录；本轮未修改存储格式，旧计划不会被新模板替换。
- `project/js/app.js`：渲染、hash 路由与交互；实践地址为 `#/practice/<id>`。
- `project/css/learning.css`：补充阅读组件，复用原有设计变量。
- `project/materials/`：原创教学材料与可下载 ZIP。

经典脚本按 data → learning → storage → app 顺序加载；不使用模块、运行时 fetch、CDN 或后端。修改材料后执行 `python tools/package-materials.py` 重新生成 ZIP。

人物资料保留官方标题、日期和链接。2026-09-26 更新时无法重新读取母校报道，未新增未经核实的校友事实；北京工业大学教师主页已复核博士、博士后及教学科研阶段。历史任职与职称不当作当前信息。校园问答、学习记录和方法样例均为教学模拟。

## 验证

语法与内容、存储兼容检查只需要 Node；案例测试只用 Python 标准库：

```powershell
node --check project/js/data.js
node --check project/js/learning.js
node --check project/js/storage.js
node --check project/js/app.js
node --test --test-isolation=none tests/content.test.js
python tests/practice.test.py
```

可选浏览器回归使用已安装的 Playwright 和 Microsoft Edge：`node tests/browser.test.js`。若 Playwright 不在默认模块路径，可通过 `NODE_PATH` 指向已有依赖目录；运行网站不依赖它。该测试使用隔离的无界面浏览器、本机临时端口与测试记录，不操作日常浏览器数据。

测试覆盖直接文件和 HTTP 两种访问、390px/1440px 布局、导航与历史、键盘折叠区、案例筛选、下载、计划创建编辑、刷新保存、旧备份恢复与取消、无效导入和存储不可用。截图与浏览器结果位于 `artifacts/content-depth/`。

比赛演示建议：校友公开经历 → 技能竞赛路线的具体阶段 → 网页案例与参考成品 → 创建个人计划 → 项目说明和复盘方法。所展示路线为平台教学设计，不是具体赛事的官方赛题或评分规则。
